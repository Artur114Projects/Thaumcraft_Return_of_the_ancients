package com.artur.returnoftheancients.referense;

public class Referense 
{
	public static final String MODID = "returnoftheancients";
	public static final String NAME = "Thaumcraft: Return of the ancients";
	public static final String VERSION = "0.0.1 Betta";
	public static final String ACCEPTED_MINECRAFT_VERSIONS = "1.12.2, 1.12.1";
	public static final String DEPENDENCIES = "required-after:galaxyspace@[any,);";

	public static final String CLIENT = "com.artur.returnoftheancients.proxy.ClientProxy";
	public static final String COMMON = "com.artur.returnoftheancients.proxy.CommonProxy";
}
