package com.artur.returnoftheancients.items;

import com.artur.returnoftheancients.handlers.Handler;
import com.artur.returnoftheancients.init.InitItems;
import com.artur.returnoftheancients.main.Main;
import com.artur.returnoftheancients.sounds.ModSounds;
import com.artur.returnoftheancients.utils.interfaces.IHasModel;

import net.minecraft.client.Minecraft;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ItemGavno extends BaseItem{

	private int i = 3100;

	public ItemGavno(String name) {
		super(name);
		setMaxStackSize(8);

	}

	@Override
	public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
		tooltip.add("DON'T DROP!!!!!!!");
	}

	@Override
	public boolean onEntityItemUpdate(EntityItem entityItem) {
		i++;
		if (entityItem.world.isAnyPlayerWithinRangeAt(entityItem.posX, entityItem.posY, entityItem.posZ, 16)) {
			if (i >= 3120) {
				Handler.playSound(ModSounds.MEGALOVANIA);
				Minecraft.getMinecraft().player.sendMessage(new TextComponentString(TextFormatting.RED + "BOSS FIGHT!!!"));
				i = 0;
			}
		}
		return super.onEntityItemUpdate(entityItem);
	}
}
