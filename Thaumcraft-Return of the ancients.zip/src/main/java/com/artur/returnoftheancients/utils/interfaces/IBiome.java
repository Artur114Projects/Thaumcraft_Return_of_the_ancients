package com.artur.returnoftheancients.utils.interfaces;

public interface IBiome {
    public void registerBiome();
}
