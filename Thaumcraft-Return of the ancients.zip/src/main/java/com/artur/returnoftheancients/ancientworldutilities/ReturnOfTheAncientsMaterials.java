package com.artur.returnoftheancients.ancientworldutilities;

import net.minecraft.item.Item;
import net.minecraftforge.common.util.EnumHelper;

public class ReturnOfTheAncientsMaterials {
    public static final Item.ToolMaterial TOOLMAT_PRIMAL = EnumHelper.addToolMaterial("toolmat_primal", 0, 0, 0, 20, 10);
}
