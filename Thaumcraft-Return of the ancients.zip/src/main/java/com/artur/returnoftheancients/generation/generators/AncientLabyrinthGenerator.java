package com.artur.returnoftheancients.generation.generators;


import com.artur.returnoftheancients.handlers.Handler;
import com.artur.returnoftheancients.init.InitDimensions;
import com.artur.returnoftheancients.utils.interfaces.IALGS;
import com.artur.returnoftheancients.utils.interfaces.IStructure;
import net.minecraft.entity.Entity;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import thaumcraft.api.capabilities.IPlayerWarp;
import thaumcraft.common.lib.capabilities.PlayerWarp;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class AncientLabyrinthGenerator implements IStructure, IALGS{
    private static final byte[][] ANCIENT_LABYRINTH_STRUCTURES = new byte[17][17];
    private static final byte[][] ANCIENT_LABYRINTH_STRUCTURES_ROTATE = new byte[17][17];
    private static final byte SIZE = 17;
    private static World world;
    public static boolean isGen = false;
    public static byte PHASE = -1;
    private static final byte[] YX_states = new byte[2];
    private static int bossGen = 0;
    /*
    [[0][1][2][3][4][5][6][7][8]] 0
    [[0][1][2][3][4][5][6][7][8]] 1
    [[0][1][2][3][4][5][6][7][8]] 2
    [[0][1][2][3][4][5][6][7][8]] 3
    [[0][1][2][3][4][5][6][7][8]] 4
    [[0][1][2][3][4][5][6][7][8]] 5
    [[0][1][2][3][4][5][6][7][8]] 6
    [[0][1][2][3][4][5][6][7][8]] 7
    [[0][1][2][3][4][5][6][7][8]] 8


    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 4, 1, 0, 0, 0, 0],
    [4, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 4, 1, 6, 1, 0, 0, 0],
    [4, 1, 0, 0, 0, 4, 1, 0, 0],
    [0, 4, 1, 0, 0, 0, 4, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 4, 1, 4, 1]

    [0, 4, 1, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 4, 1, 1, 4, 1],
    [0, 0, 0, 0, 0, 0, 4, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 6, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 4],
    [0, 0, 4, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 4, 1, 4, 1, 1, 4]

    [0, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 1],
    [0, 0, 1, 1, 1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 1, 1, 1, 1, 1]

    [4, 1, 1, 1, 1, 1, 1, 4, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 4, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 4, 1, 1, 1, 1],
    [4, 1, 4, 1, 6, 1, 1, 4, 1],
    [1, 1, 4, 1, 1, 1, 1, 4, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 1, 1, 4, 1, 1]
     */
    public static byte[][] getAncientLabyrinthStructures() {return ANCIENT_LABYRINTH_STRUCTURES;}
    public static byte[][] getAncientLabyrinthStructuresRotate() {return ANCIENT_LABYRINTH_STRUCTURES_ROTATE;}

    // генерация структуры
    private static void genRandomStructures() {
        ANCIENT_LABYRINTH_STRUCTURES[8][8] = ENTRY_ID;
        ANCIENT_LABYRINTH_STRUCTURES_ROTATE[8][8] = ROTATE_MAX[ENTRY_ID - 1];
        for (byte q = 0; q != 8; q++) {
            boolean foundRandom = false;
            byte x = 0;
            byte y = 0;
            while (!foundRandom) {
                x = (byte) Handler.genRandomIntRange(0, 16);
                y = (byte) Handler.genRandomIntRange(0, 16);
                foundRandom = ANCIENT_LABYRINTH_STRUCTURES[y][x] == 0;
            }
            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = ROTATE_MAX[CROSSROADS_ID - 1];
        }
        boolean foundRandom = false;
        byte x = 0;
        byte y = 0;
        while (!foundRandom) {
            x = (byte) Handler.genRandomIntRange(0, 16);
            y = (byte) Handler.genRandomIntRange(0, 16);
            if (x + 1 <= SIZE - 1 && y + 1 <= SIZE - 1) {
                foundRandom = ANCIENT_LABYRINTH_STRUCTURES[y][x] == 0 &&
                        ANCIENT_LABYRINTH_STRUCTURES[y][x + 1] == 0 &&
                        ANCIENT_LABYRINTH_STRUCTURES[y + 1][x] == 0 &&
                        ANCIENT_LABYRINTH_STRUCTURES[y + 1][x + 1] == 0 && x >= 12 || x <= 4 &&  y >= 12 || y <= 4;
            }
        }
        ANCIENT_LABYRINTH_STRUCTURES[y][x] = BOSS_ID;
        ANCIENT_LABYRINTH_STRUCTURES[y][x + 1] = BOSS_ID;
        ANCIENT_LABYRINTH_STRUCTURES[y + 1][x] = BOSS_ID;
        ANCIENT_LABYRINTH_STRUCTURES[y + 1][x + 1] = BOSS_ID;
    } // Gen Random Structures

    private static void genDownUpWay() {
        for (byte y = 0; y != SIZE; y++) {
            for (byte x = 0; x != SIZE; x++) {
                byte unoYStructure = 0;
                byte unoYStructureRotate = 0;
                if (y > 0) {
                    unoYStructure = ANCIENT_LABYRINTH_STRUCTURES[y - 1][x];
                    unoYStructureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y - 1][x];
                }
                byte structure = ANCIENT_LABYRINTH_STRUCTURES[y][x];
                byte structureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x];
                // Generate to Y
                if (unoYStructure == CROSSROADS_ID || unoYStructure == ENTRY_ID || unoYStructure == WAY_ID || unoYStructure == BOSS_ID) {
                    if (unoYStructure == WAY_ID && unoYStructureRotate == 2) {
                        if (structure == 0) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 2;
                        }
                        if (structure == WAY_ID && structureRotate == 1) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                    }
                    if (unoYStructure != WAY_ID) {
                        if (structure == 0) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 2;
                        }
                        if (structure == WAY_ID && structureRotate == 1) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                    }
                }
            }
        } // Gen Down Way
        for (byte y = SIZE - 1; y != -1; y--) {
            for (byte x = SIZE - 1; x != -1; x--) {
                byte unoYStructure = 0;
                byte unoYStructureRotate = 0;
                if (y < SIZE - 1) {
                    unoYStructure = ANCIENT_LABYRINTH_STRUCTURES[y + 1][x];
                    unoYStructureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y + 1][x];
                }
                byte structure = ANCIENT_LABYRINTH_STRUCTURES[y][x];
                byte structureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x];
                // Generate to Y
                if (unoYStructure == CROSSROADS_ID || unoYStructure == ENTRY_ID || unoYStructure == WAY_ID || unoYStructure == BOSS_ID) {
                    if (unoYStructure == WAY_ID && unoYStructureRotate == 2) {
                        if (structure == 0) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 2;
                        }
                        if (structure == WAY_ID && structureRotate == 1) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                    }
                    if (unoYStructure != WAY_ID) {
                        if (structure == 0) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 2;
                        }
                        if (structure == WAY_ID && structureRotate == 1) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                    }
                }
            }
        } // Gen Up Way
    }

    private static void genRightLeftWay() {
        for (byte y = 0; y != SIZE; y++) {
            for (byte x = 0; x != SIZE; x++) {
                byte unoStructure = 0;
                byte unoStructureRotate = 0;
                byte structure = ANCIENT_LABYRINTH_STRUCTURES[y][x];
                byte structureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x];
                if (x > 0) {
                    unoStructure = ANCIENT_LABYRINTH_STRUCTURES[y][x - 1];
                    unoStructureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x - 1];
                }
                // Generate to X
                if (unoStructure == CROSSROADS_ID || unoStructure == ENTRY_ID || unoStructure == WAY_ID || unoStructure == BOSS_ID) {
                    if (structure == 0 && unoStructure != WAY_ID) {
                        ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                        ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                    }
                    if (unoStructure == WAY_ID && unoStructureRotate == 1) {
                        if (structure == 0) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                        if (structure == WAY_ID && structureRotate == 2) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                    }
                }
            }
        } // Gen Right Way
        for (byte y = SIZE - 1; y != -1; y--) {
            for (byte x = SIZE - 1; x != -1; x--) {
                byte unoStructure = 0;
                byte unoStructureRotate = 0;
                byte structure = ANCIENT_LABYRINTH_STRUCTURES[y][x];
                byte structureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x];
                if (x < SIZE - 1) {
                    unoStructure = ANCIENT_LABYRINTH_STRUCTURES[y][x + 1];
                    unoStructureRotate = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x + 1];
                }
                // Generate to X
                if (unoStructure == CROSSROADS_ID || unoStructure == ENTRY_ID || unoStructure == WAY_ID || unoStructure == BOSS_ID) {
                    if (structure == 0 && unoStructure != WAY_ID) {
                        ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                        ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                    }
                    if (unoStructure == WAY_ID && unoStructureRotate == 1) {
                        if (structure == 0) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = WAY_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                        if (structure == WAY_ID && structureRotate == 2) {
                            ANCIENT_LABYRINTH_STRUCTURES[y][x] = CROSSROADS_ID;
                            ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 1;
                        }
                    }
                }
            }
        } // Gen Left Way
    }

    // размещение структур
    private static void genStructuresInWorld() {
        for (byte y = 0; y != SIZE; y++) {
            for (byte x = 0; x != SIZE; x++) {
                byte structure = ANCIENT_LABYRINTH_STRUCTURES[y][x];
                byte structureRotate  = ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x];
                int cx = 128 - 16 * x;
                int cz = 128 - 16 * y;
                int dx = 0;
                int dz = 0;
                switch (structureRotate) {
                    case 1:
                        settings.setRotation(Rotation.NONE);
                        break;
                    case 2:
                        settings.setRotation(Rotation.CLOCKWISE_90);
                        dx = -15;
                        break;
                    case 3:
                        settings.setRotation(Rotation.COUNTERCLOCKWISE_90);
                        dz = -15;
                        break;
                    case 4:
                        settings.setRotation(Rotation.CLOCKWISE_180);
                        break;
                }
                cx = cx - dx;
                cz = cz - dz;
                switch (structure) {
                    case WAY_ID:
                        GenStructure.generateStructure(world, cx, 80, cz, WAY_STRING_ID);
                        break;
                    case CROSSROADS_ID:
                        GenStructure.generateStructure(world, cx, 80, cz, CROSSROADS_STRING_ID);
                        break;
                    case ENTRY_ID:
                        GenStructure.generateStructure(world, cx, 80, cz, ENTRY_STRING_ID);
                        break;
                    case BOSS_ID:
                        bossGen++;
                        if (bossGen == 4) {
                            GenStructure.generateStructure(world, cx, 79, cz, BOSS_STRING_ID);
                            bossGen = 0;
                        }
                        break;
                    case 0:
                        System.out.println("void");
                        break;
                    default:
                        System.out.println("WTF????? " + structure);
                        break;
                }
                ANCIENT_LABYRINTH_STRUCTURES[y][x] = 0;
                ANCIENT_LABYRINTH_STRUCTURES_ROTATE[y][x] = 0;
                YX_states[0] = y;
                YX_states[1] = x;
            }
        }
        settings.setRotation(Rotation.NONE);
    }

    private static void clearArea() {
        for (byte y = 0; y != SIZE; y++) {
            for (byte x = 0; x != SIZE; x++) {
                int cx = 128 - 16 * x;
                int cz = 128 - 16 * y;
                GenStructure.generateStructure(world, cx, 80, cz, AIR_CUBE_STRING_ID);
                GenStructure.generateStructure(world, cx, 80 - 31, cz, AIR_CUBE_STRING_ID);
                YX_states[0] = y;
                YX_states[1] = x;
            }
        }
    }

    private static void reloadLight() {
        for (int z = -128; z != 144; z++) {
            for (int x = -128; x != 144; x++) {
                world.checkLight(new BlockPos(x, 84, z));
            }
        }
        for (int z = 6; z != 10; z++) {
            for (int x = 6; x != 10; x++) {
                for (int y = 82; y != 255; y++) {
                    world.checkLight(new BlockPos(x, y, z));
                }
            }
        }
    }

    private static void genAncientEntryWay() {
        for (int y = 0, cordY = 112; cordY < world.getHeight(); y++) {
            cordY = 112 + 32 * y;
            GenStructure.generateStructure(world, 0, cordY, 0, ENTRY_WAY_STRING_ID);
        }
        GenStructure.generateStructure(world, 6, 255, 6, "ancient_border_cap");
    }

    // разное
    public static float getPercentages() {
        return (float) (((16 * YX_states[0]) + (YX_states[1] + 1)) / 2.89);
    }

    public static void genAncientLabyrinth() {
        isGen = false;
        world = worldServer.getMinecraftServer().getWorld(InitDimensions.ancient_world_dim_id);
        System.out.println("Generating ancient labyrinth start");
        PHASE = 0;
        genRandomStructures();
        System.out.println(Arrays.deepToString(ANCIENT_LABYRINTH_STRUCTURES));
        genRightLeftWay();
        PHASE = 1;
        System.out.println(Arrays.deepToString(ANCIENT_LABYRINTH_STRUCTURES));
        genDownUpWay();
        PHASE = 2;
        System.out.println(Arrays.deepToString(ANCIENT_LABYRINTH_STRUCTURES));
        System.out.println("Generating Ancient Entry Way");
        PHASE = 3;
        genAncientEntryWay();
        System.out.println("Cleaning area");
        PHASE = 4;
        clearArea();
        System.out.println("Generate structures");
        PHASE = 5;
        genStructuresInWorld();
        System.out.println("Reload light");
        PHASE = 6;
        reloadLight();
        System.out.println("Generate ancient labyrinth finish!");
        PHASE = 7;
        isGen = true;
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
//        PlayerWarp.Provider playerWarp = new PlayerWarp.Provider();
//        playerWarp.
    }
}
