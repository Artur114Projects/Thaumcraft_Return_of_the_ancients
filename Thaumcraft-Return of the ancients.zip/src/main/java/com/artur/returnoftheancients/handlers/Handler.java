package com.artur.returnoftheancients.handlers;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.util.Random;

public class Handler {

    public static boolean isTriggered = false;
    public static boolean noCollision = false;

    public static int genRandomIntRange(int min, int max) {
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }

    public static void playSound(SoundEvent e) {
        System.out.println("playSound start");
        if (FMLCommonHandler.instance().getMinecraftServerInstance().getServer() != null)
            Minecraft.getMinecraft().player.playSound(e, 1.0F, 1.0F);
    }

    public static int CalculateGenerationHeight(World world, int x, int z) {
        int y = world.getHeight();
        boolean foundGround = false;

        while (!foundGround && y-- >= 0) {
            Block block = world.getBlockState(new BlockPos(x,y,z)).getBlock();
            if (block != Blocks.AIR)
                break;
        }
        System.out.println("Calculate: " + y);
        return y;
    }
}
