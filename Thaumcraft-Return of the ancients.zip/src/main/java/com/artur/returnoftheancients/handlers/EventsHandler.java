package com.artur.returnoftheancients.handlers;

import com.artur.returnoftheancients.ancientworldutilities.WorldData;
import com.artur.returnoftheancients.generation.generators.GenStructure;
import com.artur.returnoftheancients.init.InitBiome;
import com.artur.returnoftheancients.sounds.ModSounds;
import com.artur.returnoftheancients.utils.interfaces.IALGS;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import thaumcraft.api.blocks.BlocksTC;
import thaumcraft.api.capabilities.IPlayerWarp;
import thaumcraft.api.capabilities.ThaumcraftCapabilities;


import static com.artur.returnoftheancients.init.InitDimensions.ancient_world_dim_id;


public class EventsHandler {

    int t = 0;
    int i = 0;
    public static boolean tpToHome = false;
    boolean capIsSet = true;
    boolean startUp = false;
    public static boolean bossIsDead = false;


    @SubscribeEvent
    public void WorldEventLoad(WorldEvent.Load e) {
        WorldData worldData = WorldData.get();
        if (!worldData.saveData.getBoolean(IALGS.isAncientPortalGenerateKey)) {
            if (worldData.saveData.getInteger(IALGS.AncientPortalYPosKey) == 0)
                worldData.saveData.setInteger(IALGS.AncientPortalYPosKey, Handler.CalculateGenerationHeight(e.getWorld(), 8, 8));
            for (byte q = 0; q != 4; q++) {
                GenStructure.generateStructure(e.getWorld(), 8 - 3, Handler.CalculateGenerationHeight(e.getWorld(), 8, 8) - 31, 8 - 3, "ancient_portal");
            }
            GenStructure.generateStructure(e.getWorld(), 8 - 3, 0,8 -3, "ancient_portal_floor");
            worldData.saveData.setBoolean(IALGS.isAncientPortalGenerateKey, true);
        }
        worldData.markDirty();
    }

    @SubscribeEvent
    public void LivingDeathEvent(LivingDeathEvent e) {
        World world = e.getEntity().world;
        if (!e.getEntity().isNonBoss() && world.provider.getDimension() == ancient_world_dim_id && !world.isRemote) {
            WorldData worldData = WorldData.get();
            if (!worldData.saveData.getBoolean("IsPrimalBladeDrop")) {
                GenStructure.generateStructure(world, (int) e.getEntity().posX, (int) e.getEntity().posY, (int) e.getEntity().posZ, "ancient_loot");
                worldData.saveData.setBoolean("IsPrimalBladeDrop", true);
                worldData.markDirty();
            }
            bossIsDead = true;
            System.out.println("Boss is dead");
        }
    }

    @SubscribeEvent
    public void LivingHurtEvent(LivingHurtEvent e) {
        if (e.getEntity() instanceof EntityPlayer) {
            if (e.getEntity().dimension == ancient_world_dim_id) {
                EntityPlayer player = (EntityPlayer) e.getEntity();
                if (player.getHealth() - e.getAmount() <= 0) {
                    e.setCanceled(true);
                    player.setHealth(20);
                    int y = WorldData.get().saveData.getInteger(IALGS.AncientPortalYPosKey) - 50;
                    if (y == 0 || y == 1) {
                        y = 4;
                    }
                    player.removePotionEffect(Potion.getPotionById(19));
                    player.removePotionEffect(Potion.getPotionById(20));
                    FreeTeleporter.teleportToDimension(player, 0, 8, y, 8);
                    System.out.println("You dead");
                    tpToHome = true;
                }
            }
        }
    }

    @SubscribeEvent
    public void BreakEvent(BlockEvent.BreakEvent e) {
        if (e.getPlayer().dimension == ancient_world_dim_id) {
            if (!e.getPlayer().capabilities.isCreativeMode)
                e.setCanceled(true);
            if (BlocksTC.nitor.get(EnumDyeColor.BLACK).getBlockState().equals(e.getState())) {
                System.out.println("nitor is break");
            }
        }
    }

    @SubscribeEvent
    public void PlaceEvent(BlockEvent.PlaceEvent e) {
        if (e.getPlayer().dimension == ancient_world_dim_id) {
            if (!e.getPlayer().capabilities.isCreativeMode)
                e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void fogSetColor(EntityViewRenderEvent.FogColors e) {
        if (e.getEntity().getEntityWorld().getBiome(e.getEntity().getPosition()) == InitBiome.ANCIENT_LABYRINTH) {
            e.setRed(0);
            e.setBlue(0);
            e.setGreen(0);
        }
    }

    @SubscribeEvent
    public void PlayerTickEvent(TickEvent.PlayerTickEvent e) {
        if (startUp) {
            EntityPlayer player = Minecraft.getMinecraft().player;
            if (player.motionY < 2) {
                player.motionY = player.motionY + 0.1;
                t++;
            }
            if (t == 40) {
                t = 0;
                player.motionY = player.motionY + 3;
                startUp = false;
                Handler.noCollision = false;
            }
            player.motionX = 0;
            player.motionZ = 0;
        }
        GameSettings Settings = Minecraft.getMinecraft().gameSettings;
        int playerDimension = e.player.dimension;
        BlockPos pos = e.player.getPosition();
        IPlayerWarp playerWarp = ThaumcraftCapabilities.getWarp(e.player);
        if (tpToHome && playerDimension != ancient_world_dim_id) {
            i++;
            if (i >= 20 && e.player.getServer() != null) {
                if (e.player instanceof EntityPlayerMP) {
                    Handler.noCollision = true;
                    playerWarp.set(IPlayerWarp.EnumWarpType.PERMANENT, e.player.getEntityData().getInteger("PERMANENT"));
                    playerWarp.set(IPlayerWarp.EnumWarpType.TEMPORARY, e.player.getEntityData().getInteger("TEMPORARY"));
                    playerWarp.set(IPlayerWarp.EnumWarpType.NORMAL, e.player.getEntityData().getInteger("NORMAL"));
                    EntityPlayerMP playerMP = (EntityPlayerMP) e.player;
                    playerWarp.sync(playerMP);
                    startUp = true;
                    int r = e.player.getEntityData().getInteger("renderDistanceChunks");
                    float g = e.player.getEntityData().getFloat("gammaSetting");
                    if (r != 0) {
                        Settings.renderDistanceChunks = r;
                    }
                    Settings.gammaSetting = g;
                    tpToHome = false;
                    e.player.getEntityData().setBoolean("isWarpSet", false);
                    i = 0;
                }
            }
        }
        if (playerDimension == ancient_world_dim_id) {
            if (pos.getY() > 82 && e.player.motionY < -1) {
                e.player.fallDistance = 0;
                e.player.motionY = e.player.motionY + 0.1;
            }
            if (e.player.getActivePotionEffect(MobEffects.NIGHT_VISION) != null && !e.player.capabilities.isCreativeMode) {
                e.player.removePotionEffect(MobEffects.NIGHT_VISION);
                e.player.sendMessage(new TextComponentString("Only darkness"));
            }
            if (Settings.gammaSetting != 0 && !e.player.isCreative()) {
                e.player.getEntityData().setFloat("gammaSetting", Settings.gammaSetting);
                Settings.gammaSetting = 0;
                e.player.sendMessage(new TextComponentString("Only darkness"));
            }
            if (Settings.renderDistanceChunks != 4 && !e.player.isCreative()) {
                e.player.getEntityData().setInteger("renderDistanceChunks", Settings.renderDistanceChunks);
                Settings.renderDistanceChunks = 4;
                e.player.sendMessage(new TextComponentString("Only darkness"));
            }
            if (Settings.difficulty == EnumDifficulty.PEACEFUL && !e.player.isCreative()) {
                Settings.difficulty = EnumDifficulty.HARD;
                e.player.sendMessage(new TextComponentString("Peaceful???"));
            }
            if (!(e.player.getEntityData().getBoolean("isWarpSet") && e.player instanceof EntityPlayerMP && e.player.getServer() != null)) {
                if (e.player instanceof EntityPlayerMP) {
                    e.player.getEntityData().setInteger("PERMANENT", playerWarp.get(IPlayerWarp.EnumWarpType.PERMANENT));
                    e.player.getEntityData().setInteger("TEMPORARY", playerWarp.get(IPlayerWarp.EnumWarpType.TEMPORARY));
                    e.player.getEntityData().setInteger("NORMAL", playerWarp.get(IPlayerWarp.EnumWarpType.NORMAL));
                    e.player.getEntityData().setBoolean("isWarpSet", true);
                    playerWarp.set(IPlayerWarp.EnumWarpType.PERMANENT, 100);
                    EntityPlayerMP playerMP = (EntityPlayerMP) e.player;
                    playerWarp.sync(playerMP);
                }
            }
        }
        if (playerDimension == ancient_world_dim_id && !capIsSet) {
            if (pos.getY() == 81 && pos.getX() <= 9 && pos.getX() >= 6 && pos.getZ() <= 9 && pos.getZ() >= 6) {
                Handler.playSound(ModSounds.TP_SOUND);
                GenStructure.generateStructure(e.player.world, 6, 85, 6, "ancient_cap");
                capIsSet = true;
            }
        }
    }

    @SubscribeEvent
    public void PlayerChangedDimensionEvent(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.toDim == ancient_world_dim_id) {
            if (e.player.isCreative()) {
                e.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 999999, 0));
            }
            capIsSet = false;
            WorldData worldData = WorldData.get();
            worldData.saveData.setBoolean(IALGS.isBossSpawn, false);
            worldData.markDirty();
        }
    }

    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (!WorldData.get().saveData.getBoolean(IALGS.isBossSpawn) && event.getWorld().provider.getDimension() == ancient_world_dim_id && !event.getEntity().isNonBoss()) {
            event.setCanceled(true);
        }
    }
}