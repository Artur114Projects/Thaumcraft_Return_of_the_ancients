package com.artur.returnoftheancients.utils.interfaces;

public interface IHasModel {
	void registerModels();
}
